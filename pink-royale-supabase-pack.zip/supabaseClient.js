// supabaseClient.js
const SUPABASE_URL = 'https://etrloqzktcqjgbxzmurr.supabase.co';
const SUPABASE_ANON_KEY = 'PASTE_YOUR_ANON_KEY';
const { createClient } = supabase;
window.sb = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
